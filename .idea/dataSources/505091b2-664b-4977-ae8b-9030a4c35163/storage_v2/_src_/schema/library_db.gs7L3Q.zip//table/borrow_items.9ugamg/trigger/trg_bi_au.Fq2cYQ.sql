create definer = root@localhost trigger trg_bi_au
    after update
    on borrow_items
    for each row
BEGIN
  IF OLD.status = 'BORROWED' AND NEW.status = 'RETURNED' THEN
    UPDATE book_copies
    SET status = 'AVAILABLE'
    WHERE copy_id = NEW.copy_id;
  END IF;

  IF OLD.status = 'BORROWED' AND NEW.status = 'DAMAGED' THEN
    UPDATE book_copies
    SET status = 'REMOVED'
    WHERE copy_id = NEW.copy_id;
  END IF;
END;

