create definer = root@localhost trigger trg_bi_ai
    after insert
    on borrow_items
    for each row
BEGIN
  UPDATE book_copies
  SET status = 'BORROWED'
  WHERE copy_id = NEW.copy_id AND status = 'AVAILABLE';

  IF ROW_COUNT() = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Copy is not AVAILABLE, cannot borrow.';
  END IF;
END;

