create definer = root@localhost trigger trg_copies_ai
    after insert
    on book_copies
    for each row
BEGIN
  UPDATE books
  SET total_copies     = total_copies + CASE WHEN NEW.status <> 'REMOVED' THEN 1 ELSE 0 END,
      available_copies = available_copies + CASE WHEN NEW.status = 'AVAILABLE' THEN 1 ELSE 0 END
  WHERE book_id = NEW.book_id;
END;

